/* Generated automatically. */
static const char configuration_arguments[] = "/home/travis/gcc_src/configure --prefix /home/travis/gcc7_install/ --enable-languages=c --disable-bootstrap --enable-nls";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "x86-64" } };
